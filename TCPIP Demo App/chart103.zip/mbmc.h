// defines and structures for MBMC networking
#define	__MBMCAPP_H
#define MBMC_VERSION "    MBMC  21.2B FB  "
#define	MAGIC		0x0212  // data version checkmark
#define	START1		"Power Up, Init started             "	// first LCD message
#define	PIC_8722	8722
#define	CHECK_DATE	1305123894ul

#define MASK9BIT	0x0100
#define	MBMC_CHART_POINTS	24
#define	LPCHAN	16

/* PV array defines for energy tracking */
/* array spec V,I,P	*/
#define A_VPM		17300.0 	// array voltage at power max, millivolts units
#define	A_IPM		190.75  	// array current at power max,  0.1 A units
#define	A_SSC		210.75  	// array short circuit current, 0.1 A units
#define	PV_MAX		3299975ul 	// max possible power/10000 for W

/* battery Ah caps	*/
#define B1AH		225     // FLA costco
#define	B2AH		105    	// FLA bi-mart
#define B3AH		12      // gell cell
#define	B4AH		12      // gell cell
#define	PerkC1		1.26    // Peukert Comp Batt #1
#define PerkC2		1.30	// Peukert Comp Batt #2
#define Perk_ADJ_FL	0.55	// If the peukert_adj is below this, adjust the Ah out by this Ah adjustment factor
#define	CEF_HSOC	0.70    // Charge Efficiency Factor, high SOC
#define	CEF_LSOC	0.95    // Charge Efficiency Factor, low SOC
#define CEF_MAX		1.0 	// Invalid charge factor above this
#define CEF_MIN		0.33	// Invalid charge factor below this
#define	SOC_DERATE	85      // derate CEF above this
#define SOC_CEF		80		// Max state of charge to update dynamic charge efficiency factors
#define MAXALM		7		// alarm message buffer size

#define	DF			1.0     // discharge floor of battery total Ah
#define	DCURRENT	0.0     // default discharge current 0.1A units "3.6 is the lowest possible value = .36Ah", use AH_DAY_OFF
#define	AH_DAY_LOSS1	20l      // Ah lost in 24 hours from natural discharge or controller usage BATT1.
#define	AH_DAY_LOSS2	20l      // Ah lost in 24 hours from natural discharge or controller usage BATT2.
#define	SS_RATE		2.5     // STATIC SOC RATE Ah factor for static voltage cal to SOC

#define	HELP_SOC	65u      // state of charge to begin charger help in morning
#define SOCFULL		90u      // this is as good a full charge after a full C40 cycle timeout or float

#define SDINFO	0			// SD card data info block
#define SDSTART	1			// SD card first data block
#define	SDC0EEP	510         // start address of SD mirror block data in EEPROM

#include <GenericTypeDefs.h>

struct harvesttype{
        LONG energy, usage, prev_energy, prev_usage, e_total, u_total; 
		LONG count, charger, c_total, prev_charger, diversion;
};

typedef struct SDCARD {
        WORD magic;
        BYTE sdtype, sdinit, sddetect, DAYCLOCK;
        DWORD sdpos, sdnext, timekeep, time;
        struct harvesttype harvest;
        SHORT h[2][9];                  // battery history data
} SDCARD_TYPE;

typedef struct SD_VOLUME_INFO {
        DWORD size_MB;
        DWORD sector_multiply, read_block_len;
        DWORD sector_count, serial;
        BYTE name[6];
} VOLUME_INFO_TYPE;

typedef struct SDDUMP {
        BYTE dumping, type;
        DWORD sdpos;
} SDDUMP_TYPE;

//#define	sd_data_format	"\r\n^^^,1,%lu,%lu,%u,%u,%u,%lu,%lu,%lu,%lu, %li,%li,%li,%li,%li,%li, %li,%li,%li,%li, %lu,%lu,%lu,%lu,%lu,%u,%u, %lu,%lu,%lu,%lu,%lu,%li,%li,%li, %u,%u,%u,%u, %c,%c,%c,%c, %lu,%lu"

struct ccstype {
        BYTE pick, boi, boc, alert, bn;
};

#if defined(__MBMC_C)
struct celltype {							// C18 uses byte alignment
#else
struct __attribute__((aligned(1))) celltype {	// force C32 to byte alignment
#endif
        WORD id;                      //      battery cell type S,M,L
        LONG voltage, current, charge, cycles, noload, date;
        BYTE cconline, online, discharged, dead, critical, valid, fresh;
        float weight;
};

#if defined(__MBMC_C)
struct histtype {							// C18 uses byte alignment
#else
struct __attribute__((aligned(1))) histtype {	// force C32 to byte alignment
#endif
        WORD peak, rate, soc, bsoc, ce, cb, samplei, sampleo, ah, drate,esr;
        SHORT h[9];							// h[6]=cumulative battery Ah cc and inv (real),h[0]=cumulative battery Ah cc and inv (p_adj)
        LONG kwi, kwo, ttg;
        LONG ahi, aho, ahir, ahop, thermo;			// A stored in battery, A taken from battery, A from raw pv, peukert adjusted A
        LONG pv_eff, tot_eff;         		// pv generation eff factor, total system eff factor
        float peukert, cef, peukert_adj,cef_calc,cef_save;
};

struct buttype {
        DWORD bvi, bvo;
        SHORT boc, boi;
        LONG bii, bio, bil;
};                              // battery voltage in/out, battery  current in/out/load ,battery on charge, battery on inverter, battery inverter load

struct almtype {
        BYTE	alm_flag, alm_count;
};
struct almbuffertype {
	BYTE	alm_num,bn;
};

struct mbmccmdtype {
        WORD	ready,cmd;
};

struct datadefaulttype {
		DWORD	data_default;
};

struct lcdb {
        CHAR b[22];
};

struct timeruntype {
        DWORD hour, day, weeks;
};

struct mbmcnettype {
        BYTE 	*mbmc_byte;
		WORD	mbmc_index,mbmc_len;
};

/*
 *
 * This application is designed for use with the
 * ET-BASE PIC8722 board, LCD display and XANTREX C40 charge controller.
 *
 * RS-232 host commands 9600baud 8n1
 * A		send controller/battery status
 * B		select battery for modify commands, used with S M L
 * C		(NOT DONE YET)
 * D 		Calibrate ADC voltages.
 * E		When in FAIL-SAVE mode switch to second battery
 * F		Force current (none critical) charge routine to exit
 * H		Dump all SD card data records to comm1 port
 * h		Dump last 10000 SD card data records to comm1 port
 * K		lockup controller causing WDT timer to reboot
 * S M L	modify selected battery type, example: ZBBMZ would set battery 2 to M type.
 * V		turn external charger on
 * v		turn external charger off
 * Z		reset command parser
 * ?		Send help menu to rs-232 terminal
 * $		fuse blown error. (NOT DONE YET)
 * ^		reset current sensor zero calibration
 * !		hold program in present date
 * *		set battery on CC to 100% SOC
 * #		display run data on terminal rs-232 port
 *
 */



#define	HOST_REQ	'0'		// request mbmc ID
#define	HOST_ACK	'1'		// data ack code, returned when finished
#define	HOST_REAL	'2'		// send mbmc realtime data
#define	HOST_CELL	'3'		// send cell data stucture
#define	HOST_HIST	'4'		// send history data structure
#define HOST_SDC0	'5'		// send a SDCARD sector
#define	HOST_CMD_F	'F'		// send FORCEOUT command to ccvoltage controller
#define	HOST_CMD_V	'V'		// send charger toggle command to ccvoltage controller
#define	HOST_CMD_v	'v'		// send charger off command to ccvoltage controller
#define	HOST_CMD_SOC	'*'		// send set SOC command to ccvoltage controller
#define	HOST_CMD_UTC_S	'6'		// start xmit of UTC time to controller
#define	HOST_CMD_UTC_E	'7'		// end xmit of UTC time to controller

// data on the SD card is saved in 512 byte records using this prinf format string
// const BYTE sd_data_layout32[] = "\r\n^^^,1,%lu,%lu,%u,%u,%u,%lu,%lu,%lu,%lu, %li,%li,%li,%li,%li,%li, %li,%li,%li,%li, %lu,%lu,%lu,%lu,%lu,%u,%u, %lu,%lu,%lu,%lu,%lu,%li,%li,%li, %u,%u,%u,%u, %c,%c,%c,%c, %lu,%lu";

// message text
#if defined(__MBMC_C)

#define BCRELAYS	PORTE
#define IORELAYS	PORTJ
#define	DIPSW		PORTD
#define	EXTIO		PORTB

const rom char \
lowbatt0[] = "\n\r Reducing battey Ah rating due to possible bad battery.\n\r",
zero0[] = "\n\r Are all current inputs at zero current? y/n ",
zero1[] = "\n\r Current sensors zero setpoints have been recalibrated.\n\r",
zero2[] = "\n\r NOT changing current sensors zero calibration!\n\r",
adcg0[] = "\n\r Select analog channel to calibrate. Enter 0-8 or n to exit. ",
adcg1[] = "\n\r Analog channel has been recalibrated.\n\r",
adcg2[] = "\n\r NOT changing analog channel gain calibration!\n\r",
adcg3[] = "\n\r Press M/m to increase adc offset or L/l to decrease offset. Press Y to save or Q to exit and NOT save.\n\r",
adcg4[] = "\n\r Saving analog channel gain calibration in EEPROM!\n\r",
hello0[] = "\n\r SolarPIC PIC18F8722 multi-battery monitor and charger - nsaspook@nsaspook.com GPL  MBMC ",
hold0[] = "\n\r ccvoltage Monitor is held in the current state until released, \n\r Press y key to release. ",
hold1[] = "\n\r ccvoltage Monitor has been released and is running.\n\r",
sync0[] = "\n\r Set battery currently charging to 100% SOC? y/n ",
sync1[] = "\n\r Battery SOC set to 100%.\n\r",
sync2[] = "\n\r Battery SOC NOT changed.\n\r",
keycmds0[] = "\n\r KEY CMDS: # Display run data, * Reset SOC to 100% on BOC, V charger on,\r\n v Charger off, ! Hold Program, ^ Reset current zero cal\n\r",
keycmds1[] = " KEY CMDS: H dump all SD records to comm1, h dump last 10000 SD records to comm1,\r\n K Lock program causing reboot, D ADC channel Cal.\r\n",
battheader0[] = " # CI  mV B1  mV B2   mAhir    mAhi    mAho      Wi      Wo  SOC  BSOC    RUN   Weight   ESR\n\n\r",
battheader1[] = " #     LDE    LDC     AD    FCC    FDC   AHUP  MINBV  MAXBV    AHUR   CEF  CEF_CAL CEF_SAV BS_AHU AHIR   BS_AHI  BS_AHO \n\n\r",
battbuffer0[] = " Battbuffer overflow >512 \r\n",
divert0[] = " D0  AC Power diversion is ON\r\n",
divert1[] = " D1  AC Power diversion is OFF\r\n";

const rom char 	\
almcode0[] = " A0  Charger on, Battery Low.\r\n",
almcode1[] = " A1  Charger on, Low Primary Battery, in irq.\r\n",
almcode2[] = " A2  Charger off, Battery Fresh.\r\n",
almcode3[] = " A3  Charger off, Failsafe Mode.\r\n",
almcode4[] = " A4  Charger on, Low Primary battery, in main.\r\n",
almcode5[] = " A5  Charger on, Morning Help.\r\n",
almcode6[] = " A6  Charger off, Morning Help.\r\n",
almcode7[] = " A7  Charger off, PV High in Float Mode.\r\n",
almcode8[] = " A8  Charger, PV below SOLARDOWN value EOD.\r\n",
almcode9[] = " A9  Charger Alarm on, Possible Dead Battery.\r\n",
almcode10[] =" A10 Day Clock, PV above SOLARUP value Daily Status reset BOD.\r\n",
almcode11[] =" A11 Charger off, Command or Logic.\r\n",
almcode12[] =" A12 Charger on,  Command or Logic.\r\n",
almcode13[] =" A13 Possible AC power glitching.\r\n",
almcode14[] =" A14 AC power off.\r\n",
almcode15[] =" A15 AC power on.\r\n";

const rom char 	\
chrgcode0[] = " C0  Charging stopped, Battery overvolt limit.\r\n",
chrgcode1[] = " C1  Charging stopped, PV voltage too low (normal).\r\n",
chrgcode2[] = " C2  Charging stopped, Terminal FORCEOUT.\r\n",
chrgcode3[] = " C3  Charging stopped, Battery in FLOAT cycle.\r\n",
chrgcode4[] = " C4  Charging stopped, PV voltage too low (critical).\r\n",
chrgcode5[] = " C5  Charging, .\r\n",
chrgcode6[] = " C6  Charging, OVERRIDE MODE.\r\n",
chrgcode7[] = " C7  Charging, Battery load test complete.\r\n",
chrgcode8[] = " C8  Charging, Started, Begin routines.\r\n",
chrgcode9[] = " C9  Charging, Done, Exit routine.\r\n",
chrgcode10[] =" C10 Charging, Battery load test starting.\r\n",
chrgcode11[] =" C11 Charging, Battery load test return.\r\n",
chrgcode12[] =" C12 Charging, In main charge loop routine.\r\n",
chrgcode13[] =" C13 Charging, Charger relay switched off.\r\n",
chrgcode14[] =" C14 Charging, POWER UNSTABLE exit from charging.\r\n",
charger0[] = "\n\r Battery in float, charger relay switched off.\n\r",
charger1[] = "\n\r Inverter battery low, charger relay switched on.\n\r";

const rom char 	\
runcode0[] = " R0  Running,  Checking for Low PV Voltage.\r\n",
runcode1[] = " R1  Running,  PV voltage above low setpoint.\r\n",
runcode2[] = " R2  Running,  Starting Battery Check.\r\n",
runcode3[] = " R3  Running,  System Ready, Starting up Monitor Operation.\r\n",
runcode4[] = " R4  Running,  Battery CRITICAL charge cycle\r\n",
runcode5[] = " R5  Running,  Battery NORMAL charge cycle.\r\n",
runcode6[] = " R6  Running,  Battery exiting, charging in FLOAT cycle.\r\n",
runcode7[] = " R7  Running,  Alert from Pick Battery.\r\n",
runcode8[] = " R8  Running,  Battery holding, charging in FLOAT cycle.\r\n",
runcode9[] = " R9  Running,  Setting battery to fully recharged.\r\n",
runcode10[] = " R10 Running,  Checking Battery load voltages.\r\n";
#endif

// SDCARD data format structure using TypeDefs for pic32 host
#if defined(__MBMC_C)
typedef struct mbmcdata {							// C18 uses byte alignment
#else
//#pragma pack(1)
typedef struct  __attribute__((aligned(1))) mbmcdata {							// force C32 to byte alignment
#endif
		LONG			ccvoltage, inputvoltage, primarypower_B1, primarypower_B2, systemvoltage;
		LONG			currentin, current, currentload;
        LONG 			thermo_batt,cef_boc;									// cef*100
        LONG			PRIPOWEROK, DIPSW;
		LONG			pick, boi, boc, alert, bn;
		LONG			CHARGER_B, DIVERSION_B;
		LONG			MBMCID,UTC;
        struct 			harvesttype harvest;
//		LONG			crc;
} mbmctype;        

typedef struct mbmcchart {
	struct mbmcdata	data[MBMC_CHART_POINTS];
	DWORD			sdate,edate,start;
	BYTE			pos,gap;
	float			avg;
} mbmccharttype;

#if defined(__MBMC_C)
#else
//#pragma pack()
#endif

struct	mbmcflagtype {
	WORD	mbmc_cmd,mbmc_data,mbmc_ack;
	WORD	host_cmd,host_data,host_ack;
	DWORD	cmd_timeout,host_timeout,data_timeout,data_len,data_pos;
	BYTE	rx_9bit,tx_9bit,mbmc_done,host_done,*data_ptr;
};

struct mbmcstatustype {
	BYTE	seq;
	BYTE	real_valid;
	BYTE	cell_valid;
	BYTE	hist_valid;
	BYTE	sdco_valid;
	BYTE	cmd_valid;
	DWORD	sent;
	DWORD	received;
	DWORD	cmdsent;
	DWORD	cmdreceived;
	DWORD	acksent;
	DWORD	ackreceived;
};


