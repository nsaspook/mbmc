#ifndef SDSPI_H_INCLUDED
#define SDSPI_H_INCLUDED

#include <p18cxxx.h>
#include <spi.h>
#include "mbmc.h"
#include "mbmc_shared.h"

void send_dummys(void); // Send 80 clocks to SD card
int initsd(void);
int disk_initialize(void); // Check for card and init via SPI
int MMC_get_volume_info(void); // Read card info
void init_sdspi(void);			// open spi port and config
unsigned char xmit_spi(unsigned char); // Send 1 byte to card
unsigned char rcvr_spi(void); // Receive 1 byte from card
int mmc_write_block(unsigned long); // Write SDBUFFERSIZE bytes to card at block address (SDHC style)
int mmc_read_block(unsigned long); // Read SDBUFFERSIZE bytes from card at block address (SHDC style)
void wipe_sdbuffer(void); // write all zeros to sd card buffer

extern  unsigned char csd[SD_18], cid[SD_18];
extern  VOLUME_INFO_TYPE MMC_volume_Info, *vinf;
extern  far char block_buffer[SDBUFFERSIZE+SDBUFFER_EXTRA];
extern	void wdttime(unsigned long int);

#endif /* SDSPI_H_INCLUDED */

